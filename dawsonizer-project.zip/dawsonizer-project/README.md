# DAWSONIZER

Transform AI drafts into authentic Dawson Construction copy.

## Quick Deploy to Vercel (5 minutes)

### Step 1: Get an Anthropic API Key
1. Go to [console.anthropic.com](https://console.anthropic.com/)
2. Create an account or sign in
3. Go to API Keys and create a new key
4. Copy it somewhere safe (you'll need it in Step 4)

### Step 2: Upload to GitHub
1. Create a [GitHub](https://github.com) account if you don't have one
2. Click the **+** in the top right → **New repository**
3. Name it `dawsonizer`
4. Keep it **Private** if you want
5. Click **Create repository**
6. Upload all these files to the repository

### Step 3: Deploy on Vercel
1. Go to [vercel.com](https://vercel.com) and sign up with your GitHub account
2. Click **Add New...** → **Project**
3. Find and select your `dawsonizer` repository
4. Click **Deploy**

### Step 4: Add Your API Key
1. In Vercel, go to your project's **Settings** → **Environment Variables**
2. Add a new variable:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** Your API key from Step 1
3. Click **Save**
4. Go to **Deployments** and click the **...** menu → **Redeploy**

### Done!
Your Dawsonizer is now live at `your-project-name.vercel.app`

---

## Local Development (Optional)

If you want to run it on your own computer:

```bash
# Install dependencies
npm install

# Create .env.local file with your API key
cp .env.example .env.local
# Then edit .env.local and add your real API key

# Run the development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## Cost

The Anthropic API costs approximately $0.01-0.05 per use. Vercel hosting is free for personal projects.

---

## Support

Built for Dawson Construction. Questions? Ask Dresdon.
