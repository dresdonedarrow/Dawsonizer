import './globals.css'

export const metadata = {
  title: 'Dawsonizer',
  description: 'Transform AI drafts into authentic human copy',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
