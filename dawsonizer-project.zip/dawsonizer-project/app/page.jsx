'use client';

import { useState } from 'react';

export default function Dawsonizer() {
  const [inputCopy, setInputCopy] = useState('');
  const [outputCopy, setOutputCopy] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [postType, setPostType] = useState('');
  const [recentPhrases, setRecentPhrases] = useState('');
  const [pdfContext, setPdfContext] = useState(null);
  const [pdfName, setPdfName] = useState('');
  const [showDiff, setShowDiff] = useState(true);
  const [showOptional, setShowOptional] = useState(false);
  const [copied, setCopied] = useState(false);

  const postTypes = [
    { value: '', label: 'Select post type' },
    { value: 'project', label: 'Project Update' },
    { value: 'projectstory', label: 'Project Story (mission-driven)' },
    { value: 'community', label: 'Community / Crisis' },
    { value: 'celebration', label: 'Celebration / Milestone' },
    { value: 'partnership', label: 'Partnership / Donation' },
    { value: 'employee', label: 'Employee Spotlight' },
    { value: 'kendall', label: 'Letter from Kendall' },
  ];

  const postTypeHints = {
    project: "Lead with 'Project Update!' then celebrate the crew and progress.",
    projectstory: "Lead with 'Project Update!' then the partner's mission and why it matters.",
    community: "Lead with empathy. Show action. Let the heart come through.",
    celebration: "Celebrate the community first. Be proud and grateful.",
    partnership: "Tell the story. Show why it matters. Be genuinely excited.",
    employee: "Make it warm and human. Let their personality shine.",
    kendall: "Personal stories, specific numbers, people by name, measured pride."
  };

  const refineCopy = async () => {
    if (!inputCopy.trim()) {
      setError('Please enter some copy to refine.');
      return;
    }

    setIsLoading(true);
    setError('');
    setOutputCopy('');
    setShowDiff(true);

    try {
      const response = await fetch('/api/dawsonize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          inputCopy,
          postType,
          recentPhrases,
          pdfContext,
        }),
      });

      if (!response.ok) {
        throw new Error('API request failed');
      }

      const data = await response.json();
      setOutputCopy(data.output);
    } catch (err) {
      setError('Failed to refine copy. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(outputCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getDiff = (original, modified) => {
    const originalWords = original.split(/(\s+)/);
    const modifiedWords = modified.split(/(\s+)/);
    
    const lcs = (a, b) => {
      const m = a.length, n = b.length;
      const dp = Array(m + 1).fill(null).map(() => Array(n + 1).fill(0));
      
      for (let i = 1; i <= m; i++) {
        for (let j = 1; j <= n; j++) {
          if (a[i-1] === b[j-1]) {
            dp[i][j] = dp[i-1][j-1] + 1;
          } else {
            dp[i][j] = Math.max(dp[i-1][j], dp[i][j-1]);
          }
        }
      }
      
      const result = [];
      let i = m, j = n;
      while (i > 0 && j > 0) {
        if (a[i-1] === b[j-1]) {
          result.unshift({ type: 'same', value: a[i-1] });
          i--; j--;
        } else if (dp[i-1][j] > dp[i][j-1]) {
          result.unshift({ type: 'removed', value: a[i-1] });
          i--;
        } else {
          result.unshift({ type: 'added', value: b[j-1] });
          j--;
        }
      }
      while (i > 0) {
        result.unshift({ type: 'removed', value: a[i-1] });
        i--;
      }
      while (j > 0) {
        result.unshift({ type: 'added', value: b[j-1] });
        j--;
      }
      return result;
    };
    
    return lcs(originalWords, modifiedWords);
  };

  const renderDiff = (original, modified, showRemoved = true) => {
    const diff = getDiff(original, modified);
    
    return diff.map((part, index) => {
      if (part.type === 'same') {
        return <span key={index}>{part.value}</span>;
      } else if (part.type === 'removed' && showRemoved) {
        return (
          <span 
            key={index} 
            className="bg-red-500/30 text-red-300 line-through"
          >
            {part.value}
          </span>
        );
      } else if (part.type === 'added' && !showRemoved) {
        return (
          <span 
            key={index} 
            className="bg-emerald-500/20 text-emerald-300"
          >
            {part.value}
          </span>
        );
      }
      return null;
    });
  };

  const handlePdfUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      setError('Please upload a PDF file');
      return;
    }

    try {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target.result.split(',')[1];
        setPdfContext(base64);
        setPdfName(file.name);
      };
      reader.readAsDataURL(file);
    } catch (err) {
      setError('Failed to read PDF file');
    }
  };

  const clearPdf = () => {
    setPdfContext(null);
    setPdfName('');
  };

  return (
    <div className="min-h-screen" style={{ background: 'linear-gradient(180deg, #0f172a 0%, #1e293b 50%, #0f172a 100%)' }}>
      {/* Gradient accent line */}
      <div className="h-1" style={{ background: 'linear-gradient(90deg, #004D43 0%, #83AC40 50%, #004D43 100%)' }} />
      
      <div className="max-w-xl mx-auto px-5 py-10">
        
        {/* Header */}
        <header className="text-center mb-10">
          <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@900&display=swap" rel="stylesheet" />
          <h1 
            className="text-3xl text-white mb-2 tracking-tight"
            style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 900 }}
          >
            DAWSONIZER
          </h1>
          <p className="text-slate-400">Transform AI drafts into authentic human copy</p>
        </header>

        {/* Main Card */}
        <div 
          className="rounded-3xl p-6 mb-6"
          style={{ 
            background: 'rgba(30, 41, 59, 0.5)',
            backdropFilter: 'blur(10px)',
            border: '1px solid rgba(71, 85, 105, 0.3)'
          }}
        >
          {/* Post Type */}
          <div className="mb-5">
            <label className="block text-sm text-slate-300 mb-2">Post Type</label>
            <select
              value={postType}
              onChange={(e) => setPostType(e.target.value)}
              className="w-full rounded-xl px-4 py-3 text-white text-sm focus:outline-none transition-all cursor-pointer"
              style={{ 
                background: 'rgba(15, 23, 42, 0.6)',
                border: postType ? '1px solid rgba(0, 77, 67, 0.5)' : '1px solid rgba(71, 85, 105, 0.3)'
              }}
            >
              {postTypes.map((type) => (
                <option key={type.value} value={type.value}>{type.label}</option>
              ))}
            </select>
            {postType && (
              <p className="text-xs mt-2" style={{ color: '#83AC40' }}>
                {postTypeHints[postType]}
              </p>
            )}
          </div>

          {/* Optional Section Toggle */}
          <button
            onClick={() => setShowOptional(!showOptional)}
            className="w-full flex items-center justify-between px-4 py-3 rounded-xl mb-5 text-sm text-slate-400 hover:text-slate-300 transition-colors"
            style={{ 
              background: 'rgba(15, 23, 42, 0.4)',
              border: '1px solid rgba(71, 85, 105, 0.2)'
            }}
          >
            <span>Additional context (optional)</span>
            <svg 
              className={`w-4 h-4 transition-transform ${showOptional ? 'rotate-180' : ''}`} 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>

          {/* Optional Fields */}
          {showOptional && (
            <div 
              className="mb-5 p-4 rounded-xl space-y-4"
              style={{ 
                background: 'rgba(15, 23, 42, 0.4)',
                border: '1px solid rgba(71, 85, 105, 0.2)'
              }}
            >
              {/* PDF Upload */}
              <div>
                <label className="block text-xs text-slate-400 mb-2">Project background PDF</label>
                {!pdfContext ? (
                  <label 
                    className="flex items-center justify-center h-12 rounded-lg cursor-pointer transition-colors text-slate-500 hover:text-slate-400 text-sm"
                    style={{ 
                      background: 'rgba(15, 23, 42, 0.5)',
                      border: '1px dashed rgba(71, 85, 105, 0.4)'
                    }}
                  >
                    Click to upload PDF
                    <input type="file" accept="application/pdf" onChange={handlePdfUpload} className="hidden" />
                  </label>
                ) : (
                  <div 
                    className="flex items-center justify-between px-3 py-2 rounded-lg"
                    style={{ background: 'rgba(0, 77, 67, 0.2)', border: '1px solid rgba(0, 77, 67, 0.3)' }}
                  >
                    <span className="text-sm text-white truncate">{pdfName}</span>
                    <button onClick={clearPdf} className="text-xs text-slate-400 hover:text-red-400 ml-2">Remove</button>
                  </div>
                )}
              </div>

              {/* Recent Posts */}
              <div>
                <label className="block text-xs text-slate-400 mb-2">Recent posts (helps avoid repetition)</label>
                <textarea
                  value={recentPhrases}
                  onChange={(e) => setRecentPhrases(e.target.value)}
                  placeholder="Paste your last few posts here..."
                  className="w-full h-20 rounded-lg px-3 py-2 text-white text-sm placeholder-slate-600 focus:outline-none resize-none"
                  style={{ 
                    background: 'rgba(15, 23, 42, 0.5)',
                    border: '1px solid rgba(71, 85, 105, 0.3)'
                  }}
                />
              </div>
            </div>
          )}

          {/* Input */}
          <div className="mb-5">
            <label className="block text-sm text-slate-300 mb-2">Your AI draft</label>
            <textarea
              value={inputCopy}
              onChange={(e) => setInputCopy(e.target.value)}
              placeholder="Paste the AI-generated text here..."
              className="w-full h-32 rounded-xl px-4 py-3 text-white placeholder-slate-600 focus:outline-none resize-none transition-all"
              style={{ 
                background: 'rgba(15, 23, 42, 0.6)',
                border: inputCopy ? '1px solid rgba(0, 77, 67, 0.5)' : '1px solid rgba(71, 85, 105, 0.3)'
              }}
            />
          </div>

          {/* Button */}
          <button
            onClick={refineCopy}
            disabled={isLoading || !inputCopy.trim()}
            className="w-full py-3.5 rounded-xl text-white font-medium transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            style={{ 
              background: isLoading || !inputCopy.trim() 
                ? 'rgba(71, 85, 105, 0.3)' 
                : 'linear-gradient(135deg, #004D43 0%, #006B5A 100%)',
              boxShadow: isLoading || !inputCopy.trim() ? 'none' : '0 4px 20px rgba(0, 77, 67, 0.4)'
            }}
          >
            {isLoading ? (
              <span className="flex items-center justify-center gap-2">
                <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                Dawsonizing...
              </span>
            ) : 'DAWSONIZE IT!!'}
          </button>
        </div>

        {/* Error */}
        {error && (
          <div 
            className="mb-6 p-4 rounded-xl text-red-400 text-sm"
            style={{ background: 'rgba(239, 68, 68, 0.1)', border: '1px solid rgba(239, 68, 68, 0.2)' }}
          >
            {error}
          </div>
        )}

        {/* Output */}
        {outputCopy && (
          <div 
            className="mb-6 rounded-3xl p-6"
            style={{ 
              background: 'rgba(30, 41, 59, 0.5)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(131, 172, 64, 0.3)'
            }}
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-medium" style={{ color: '#83AC40' }}>Ready to post</span>
              <button
                onClick={copyToClipboard}
                className="flex items-center gap-1.5 text-sm text-slate-400 hover:text-white transition-colors"
              >
                {copied ? (
                  <>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    Copied
                  </>
                ) : (
                  <>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    </svg>
                    Copy
                  </>
                )}
              </button>
            </div>
            <p className="text-white leading-relaxed whitespace-pre-wrap">{outputCopy}</p>
          </div>
        )}

        {/* Comparison */}
        {outputCopy && inputCopy && (
          <div 
            className="mb-6 rounded-3xl p-6"
            style={{ 
              background: 'rgba(30, 41, 59, 0.3)',
              border: '1px solid rgba(71, 85, 105, 0.2)'
            }}
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-slate-400">Changes</span>
              <button
                onClick={() => setShowDiff(!showDiff)}
                className="text-xs transition-colors"
                style={{ color: showDiff ? '#83AC40' : '#64748b' }}
              >
                {showDiff ? 'Highlighting on' : 'Show highlighting'}
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <div className="text-xs text-slate-500 mb-2">
                  Original {showDiff && <span className="text-red-400/70">(removed)</span>}
                </div>
                <div 
                  className="rounded-xl p-4 text-sm text-slate-400 leading-relaxed"
                  style={{ background: 'rgba(15, 23, 42, 0.5)' }}
                >
                  {showDiff ? renderDiff(inputCopy, outputCopy, true) : inputCopy}
                </div>
              </div>
              <div>
                <div className="text-xs mb-2" style={{ color: '#83AC40' }}>
                  Dawsonized {showDiff && <span className="text-emerald-400/70">(added)</span>}
                </div>
                <div 
                  className="rounded-xl p-4 text-sm text-slate-300 leading-relaxed"
                  style={{ background: 'rgba(15, 23, 42, 0.5)', border: '1px solid rgba(131, 172, 64, 0.2)' }}
                >
                  {showDiff ? renderDiff(inputCopy, outputCopy, false) : outputCopy}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Cheat Sheet */}
        <div 
          className="rounded-3xl p-6 mb-6"
          style={{ 
            background: 'rgba(30, 41, 59, 0.3)',
            border: '1px solid rgba(71, 85, 105, 0.2)'
          }}
        >
          <h3 className="text-sm text-slate-300 mb-4">AI Red Flags Cheat Sheet</h3>
          <div className="grid grid-cols-2 gap-6">
            <div>
              <div className="text-xs uppercase tracking-wider mb-3" style={{ color: '#83AC40' }}>Say this</div>
              <ul className="space-y-2 text-sm text-slate-400">
                <li className="flex gap-2"><span style={{ color: '#83AC40' }}>→</span> We want to build...</li>
                <li className="flex gap-2"><span style={{ color: '#83AC40' }}>→</span> Safety comes first</li>
                <li className="flex gap-2"><span style={{ color: '#83AC40' }}>→</span> We use what we've got</li>
              </ul>
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider text-slate-500 mb-3">Not this</div>
              <ul className="space-y-2 text-sm text-slate-500">
                <li className="flex gap-2"><span>×</span> Foster a culture of...</li>
                <li className="flex gap-2"><span>×</span> Underscores our commitment</li>
                <li className="flex gap-2"><span>×</span> Leverage our resources</li>
              </ul>
            </div>
          </div>
          <p className="text-xs text-slate-500 mt-4 pt-4" style={{ borderTop: '1px solid rgba(71, 85, 105, 0.2)' }}>
            <span className="text-slate-400">Watch for:</span> crucial, foster, leverage, navigate, stakeholders, robust, seamless, paramount, endeavor
          </p>
        </div>

        {/* Footer */}
        <footer className="mt-12 text-center">
          <p className="text-slate-600 text-sm">Dawson Construction</p>
          <p className="text-slate-700 text-xs mt-1">Building with heart since 1950</p>
        </footer>
      </div>
    </div>
  );
}
